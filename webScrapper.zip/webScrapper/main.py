# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


import requests
from bs4 import BeautifulSoup
import PIL.Image
import urllib.request


def trig():
    def getdata(url):
        r = requests.get(url)
        return r.text

    urlbase = "https://www.drivespark.com/wallpapers/"
    urlfirst = 'https://www.drivespark.com'
    htmldata = getdata(urlbase)
    soup = BeautifulSoup(htmldata, 'html.parser')
    i = 0
    for item in soup.find_all('img'):
        temp = str(item['src'])
        if temp[-3:] == 'jpg':
            urllib.request.urlretrieve(urlfirst + temp, "car.jpg")
            im = PIL.Image.open('car.jpg')
            size = (400, 400)
            im.thumbnail(size)
            im.save('webScrap/mysite/static/mysite/images/car' + str(i) + '.jpg')
            i += 1


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    trig()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
